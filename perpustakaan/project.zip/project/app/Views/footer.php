<footer class="bg-dark text-white p-3">
    <div class="text-center">
        <p>@2023</p>
    </div>
</footer>

</body>

</html>