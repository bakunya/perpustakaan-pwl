<div class="container">
    <h1>welcome</h1>
    <p>prektek 1</p>
    <a href="/login" class="btn btn-success">login PHP</a>

    <style>
        a {
            display: inline-block;
            padding: 7px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        a:hover {
            background-color: #0069d9;
            color: white;
        }
    </style>

    <button class="btn btn-primary" onclick="window.location.href='/login'">Login JS</button>
</div>